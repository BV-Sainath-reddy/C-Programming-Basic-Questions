#include<stdio.h>
int main()
{
    int l,w,area;
    printf("enter the length , width  of rectangle:");
    scanf("%d%d",&l,&w);
    area=l*w;
    printf("area of rectangle is:%d",area);
}